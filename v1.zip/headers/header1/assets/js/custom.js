/* Open the sidenav */
function openNav() {
    document.getElementById("mobile-menu").style.width = "100%";
}

/* Close/hide the sidenav */
function closeNav() {
    document.getElementById("mobile-menu").style.width = "0";
}